PROJECT_ROOT = "/home/jean/projects/grimoire/grimoire/search_run"
MAIN_FILE = f"{PROJECT_ROOT}/entries/main.py"
LOG_FILE = "/tmp/log/main.log"
